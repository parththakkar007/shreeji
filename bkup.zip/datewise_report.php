<?php
    include("include/header.php");
?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" />
<style>
    .table{
        color:black;
    }
</style>
        
        <center><h1>DateWise Report<h1></center>
        <form method="post" >
                From:
                <input type="date" name="from" style="border:none; border-radius:5px;" class="col-md-3" value="<?php if(!empty($_REQUEST['from'])){ echo $_REQUEST['from']; }?>">
                To:
                <input type="date" name="to" style="border:none; border-radius:5px;" class="col-md-3" value="<?php if(!empty($_REQUEST['to'])){ echo $_REQUEST['to']; }?>">
                <input type="submit" name="submit" class="form-control col-md-1 btn btn-primary">
        </form>
        <div class="table-responsive" style="background-color:white;">
        <table border="1" class="table table-info">
            <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Credit</th>
                    <th>Debit</th>
                </tr>
            </thead>  
            <tbody>      
            <?php
                $condition="";
                if(!empty($_REQUEST['from'])){
                    $condition.=" AND transaction.date>='".$_REQUEST['from']."'";
                }if(!empty($_REQUEST['to'])){
                    $condition.=" AND transaction.date<='".$_REQUEST['to']."'";
                }
                $transaction=mysqli_query($con,"select DISTINCT date from transaction where 1=1 $condition order by transaction.id desc");
                 $i=0;
                while($r=mysqli_fetch_array($transaction)){
               
                $i++;
            ?>
                <tr>
                    <td><?=$i?></td>
                    <td><?=date("d-m-Y",strtotime($r['date']));?></td>
                    <td>
                        <table class="table">
                        <?php
                            $creditQ=mysqli_query($con,"select transaction.amount,party.name from transaction 
                            left join party on party.id=transaction.party_id
                            where transaction.date='".$r['date']."' AND transaction.type='credit' order by transaction.id desc");
                            $credittotal=0;
                            while($creditR=mysqli_fetch_array($creditQ)){
                                $credittotal+=$creditR['amount'];
                        ?>
                                <tr>
                                    <td style="width:50%;"><?=$creditR['name'];?></td>
                                    <td style="width:50%;"><?=$creditR['amount'];?></td>
                                </tr>
                        <?php
                            }
                        ?>
                        <tr>
                            <td class="text-success" style="width:50%;">CR Total:</td>
                            <td style="width:50%;"><b><?=$credittotal;?></b></td>
                        </tr>
                        </table>
                    </td>
                    <td>
                        <table class="table">
                        <?php
                            $debitQ=mysqli_query($con,"select transaction.amount,party.name from transaction 
                            left join party on party.id=transaction.party_id
                            where transaction.date='".$r['date']."' AND transaction.type='debit' order by transaction.id desc");
                            $debittotal=0;
                            while($debitR=mysqli_fetch_array($debitQ)){
                                $debittotal+=$debitR['amount'];
                        ?>
                                <tr>
                                    <td style="width:50%;"><?=$debitR['name'];?></td>
                                    <td style="width:50%;"><?=$debitR['amount'];?></td>
                                </tr>
                        <?php
                            }
                        ?>
                        <tr>
                            <td class="text-success" style="width:50%;">DB Total:</td>
                            <td style="width:50%;"><b><?=$debittotal;?></b></td>
                        </tr>
                        </table>
                    </td>
                </tr>            
            <?php
                }
            ?>
            </tbody>
        </table>
        </div>
<?php
include("include/footer.php");
?>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready( function () {
    $('.table').dataTable({
        "pageLength": 50
    });
});
</script>
                