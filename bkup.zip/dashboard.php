<?php
    include("include/header.php");
    $cre=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as cre from transaction where type='credit'"))['cre'];
    $dbe=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as dbe from transaction where type='debit'"))['dbe'];
    $ini=mysqli_fetch_array(mysqli_query($con,"select amount from initial_opening"))['amount'];
    $total=$cre-$dbe+$ini;
    
    $cr=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as cre from transaction where type='credit' AND date='".date("Y-m-d")."'"))['cre'];
    $db=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as dbe from transaction where type='debit' AND date='".date("Y-m-d")."'"))['dbe'];
?>
    <div class="row">
    <div class="col-md-4">
    <div class="card border-warning mb-3 col-md-3" style="max-width: 20rem;">
      <div class="card-header">Total Balance</div>
      <div class="card-body">
        <h4 class="card-title"><?=$total;?></h4>
    </div>
    </div>
    </div>
    <div class="col-md-4">
    <div class="card border-warning mb-3 col-md-3" style="max-width: 20rem;">
      <div class="card-header">Today's Credit</div>
      <div class="card-body">
        <h4 class="card-title"><?=$cr;?></h4>
    </div>
    </div>
    </div>
    <div class="col-md-4">
    <div class="card border-warning mb-3 col-md-3" style="max-width: 20rem;">
      <div class="card-header">Today's Debit</div>
      <div class="card-body">
        <h4 class="card-title"><?=$db;?></h4>
    </div>
    </div>
    </div>
    </div>
    
<?php
    include("include/footer.php");
?>
