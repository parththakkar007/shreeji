<?php
    include("include/header.php");
    
    
    
?>
        
        <center><h1>Balance Sheet<h1></center>
        <table border="1" class="table table-info">
            <tr>
                <th>Sr.No</th>
                <th>Date</th>
                <th>Opening Balance</th>
                <th>Closing Balance</th>
            </tr>
            <?php
                $R=mysqli_query($con,"select * from closing_balance order by id desc");
                $i=0;
                while($Q=mysqli_fetch_array($R)){
                    $i++;
            ?>
            <tr>
                <td><?=$i;?></td>
                <td><?=$Q['created_at'];?></td>
                <td><?=$Q['amount'];?></td>
                <td>
                    <?php
                        if($i==1){
                            $cre=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as cre from transaction where type='credit'"))['cre'];
                            $dbe=mysqli_fetch_array(mysqli_query($con,"select sum(amount) as dbe from transaction where type='debit'"))['dbe'];
                            $ini=mysqli_fetch_array(mysqli_query($con,"select amount from initial_opening"))['amount'];
                            $total=$cre-$dbe+$ini;
                            echo $total;
                        }else{
                            $P=mysqli_query($con,"select * from closing_balance where DATE(created_at)='".date('Y-m-d', strtotime($Q['created_at']. ' + 1 day'))."'");
                            $S=mysqli_fetch_array($P);
                            echo $S['amount'];
                        }
                    ?>
                </td>
            </tr>
            <?php
                }
            ?>
        </table>
        
<?php
include("include/footer.php")
?>
                